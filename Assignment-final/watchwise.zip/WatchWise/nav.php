<nav class="navbar navbar-expand-lg">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">WatchWise</a>
        <div class="d-flex">
          <a href="admin/login.php" class="nav-link">Admin Login</a>
        </div>
      </div>
</nav>
