


<div class="bg-dark text-white text-center py-3 mb-4">
    <h1 class="mb-0">Movies Administrator</h1>
</div><nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm mb-4">
  <div class="container-fluid">

    <a class="btn btn-secondary" href="javascript:history.back()">
            <i class="bi bi-arrow-left-circle"></i> Go Back
          </a>
    
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
      <li class="nav-item">
          
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="addmovie.php">Add Movie</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="logout.php">Logout</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="admin.php">Administer</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
