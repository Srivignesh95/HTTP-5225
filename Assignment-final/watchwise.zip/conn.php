<?php
  $connect = mysqli_connect('localhost', 'u235331216_AdilSurve2', 'D@iye786!786', 'u235331216_movies');
  
  if(!$connect){
    die("Connection Failed: " . mysqli_connect_error());
  }
